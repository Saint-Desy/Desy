# Responsive Login Form
## [Watch it on youtube](https://youtu.be/yEYd6D0Yno0)
### Responsive Login Form

- Responsive Animated Login Form Using HTML CSS & JAVASCRIPT
- Contains animations for input labels.
- Developed first with the Mobile First methodology, then for desktop.
- Compatible with all mobile devices and with a beautiful and pleasant user interface.

💙 Join the channel to see more videos like this. [Bedimcode](https://www.youtube.com/@Bedimcode)

![preview img](/preview.png)
